-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 18, 2022 at 02:27 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentregistration`
--

-- --------------------------------------------------------

--
-- Table structure for table `regist`
--

CREATE TABLE `regist` (
  `student_no` int(3) NOT NULL,
  `student_name` text NOT NULL,
  `student_dob` date NOT NULL,
  `student_doj` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `regist`
--

INSERT INTO `regist` (`student_no`, `student_name`, `student_dob`, `student_doj`) VALUES
(1, '0000-00-00', '0000-00-00', '0000-00-00'),
(2, 'SHUBHANGI', '0000-00-00', '0000-00-00'),
(3, 'SHUBHANGI', '2022-01-04', '2022-01-06'),
(4, 'SHUBHANGI ', '2022-01-10', '2022-01-12'),
(5, 'jdfhjsldkf', '2022-01-12', '2022-01-12'),
(6, 'shubhangi', '2022-01-04', '2022-01-12'),
(7, 'shubhangi', '2022-01-12', '2022-01-20'),
(8, 'shubhangi', '2022-01-11', '2022-01-06'),
(9, 'sgjhkgk', '2022-01-12', '2022-01-13'),
(10, 'shramika', '2022-01-12', '2022-01-15'),
(11, 'dfhdfdgvc c', '2022-01-20', '2022-01-16'),
(12, 'dhsdf', '2022-01-06', '2022-01-13'),
(14, 'fhjklfdfs', '2022-01-11', '2022-01-18'),
(15, 'kfjfksdf', '2022-01-10', '2022-01-05'),
(16, 'sjhgdskf', '2022-01-05', '2022-01-19'),
(17, 'sjhfdsylfu', '2022-01-12', '2022-01-14'),
(18, 'sdfjhdsf', '2022-01-19', '2022-01-10'),
(19, 'fkmjnkf', '2022-01-05', '2022-01-12'),
(20, 'dksfj;kl', '2022-01-18', '2022-01-11'),
(21, 'jskdjfs', '2022-01-03', '2022-01-10'),
(22, 'shubha', '2022-01-05', '2022-01-18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `regist`
--
ALTER TABLE `regist`
  ADD PRIMARY KEY (`student_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `regist`
--
ALTER TABLE `regist`
  MODIFY `student_no` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
